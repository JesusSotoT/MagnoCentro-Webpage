﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'pt-br', {
	button: 'Colar como Texto sem Formatação',
	title: 'Colar como Texto sem Formatação'
} );
